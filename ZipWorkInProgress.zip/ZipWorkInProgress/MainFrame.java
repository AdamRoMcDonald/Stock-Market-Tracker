import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;

public class MainFrame extends JFrame implements ActionListener {

    JButton loadInf;
    JButton useInf;
    JButton loadPrev;
    JButton exit;
    NextFrame NF;

    public MainFrame( StockHashTable HT, APIAccessor AI){
        NF = new NextFrame();
        this.setResizable(false);
        loadInf = new JButton();
        loadInf.addActionListener(e -> { NF.setNextFrame("loadIn", HT, AI); this.dispose(); });
        loadInf.setText("Load in new Info");
        loadInf.setFocusable(false); //Gets rid of border text around button


        useInf = new JButton();
        useInf.addActionListener(e -> NF.setNextFrame("useInf", HT, AI));
        useInf.setText("Use Loaded Info");
        useInf.setFocusable(false); //Gets rid of border text around button


        loadPrev = new JButton();

        loadPrev.addActionListener(e -> NF.setNextFrame("loadPrev", HT, AI));
        loadPrev.setText("Load Previous Session Info");
        loadPrev.setFocusable(false); //Gets rid of border text around button

        exit = new JButton();
        exit.addActionListener(e -> System.exit(0));
        exit.setText("Exit");
        exit.setFocusable(false);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setSize(600,600);
        this.setVisible(true);

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());
        topPanel.setBackground(Color.blue);
        topPanel.setBounds(0, 0, 600, 300);


        JPanel panel = new JPanel();
        panel.setBackground(Color.lightGray);
        panel.setLayout(new FlowLayout());
        panel.setBounds(0, 300, 600, 300);
        panel.add(loadInf);
        panel.add(loadPrev);
        panel.add(useInf);
        panel.add(exit);
        this.add(panel);
        this.add(topPanel);


    }



    @Override
    public void actionPerformed(ActionEvent e) {

    }
}

