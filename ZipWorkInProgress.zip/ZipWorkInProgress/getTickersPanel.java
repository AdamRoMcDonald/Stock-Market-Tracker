import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

class getTickersPanel implements ActionListener {

    LinkedList tickerNames = new LinkedList();



    public JPanel Return(String numStocks){
        JPanel tickerPanel = new JPanel();
        tickerPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        tickerPanel.setBounds(0, 0, 300, 300);
        tickerPanel.setBackground(Color.lightGray);
        JTextField tickerField = new JTextField("Ticker");
        JButton enterTickerButton = new JButton("Enter");
        System.out.println(numStocks);
        int tempNumStocks = Integer.parseInt(numStocks);
        int counter = 0;
        LinkedList<JTextField> fields = new LinkedList<>();
        for (int i = 0; i < tempNumStocks; i++) {
            JTextField tempField = new JTextField("Symbol");
            tickerPanel.add(tempField);
            fields.add(tempField);
            counter++;
        }
        tickerPanel.add(enterTickerButton);

        enterTickerButton.addActionListener(e -> {
            for (JTextField tf : fields) {
                tickerNames.add(tf.getText());
            }

        });
        return tickerPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
