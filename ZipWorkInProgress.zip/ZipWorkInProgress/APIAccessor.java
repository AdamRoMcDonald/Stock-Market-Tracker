

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Hashtable;
import java.util.LinkedList;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

import static java.lang.Math.round;

//https://api.twelvedata.com/time_series?&start_date=2020-01-06&end_date=2020-05-06&symbol=aapl&interval=1day&apikey=xxx
public class APIAccessor {
    public void infoLoader(LinkedList ticker, String startDate, String endDate, StockHashTable centralTable) {
        String APIKey = "ad6c4b6204264b9ca718dacdaf1a47f4";
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request;
        String URL;
        HttpResponse<String> response;

        System.out.println(ticker.get(0));
        if (ticker.size() < 2) {

            URL = "https://api.twelvedata.com/time_series?&start_date=" + startDate + "&end_date=" + endDate + "&symbol=" + ticker.get(0).toString() + "&interval=1day&apikey=" + APIKey;
            request = HttpRequest.newBuilder().uri(URI.create(URL)).build();
            System.out.println(URL);

            //
            //https://api.twelvedata.com/time_series?&start_date="+startDate+"&end_date="+endDate+"&symbol=AAPL,INTC&interval=1day&outputsize=30&apikey=ad6c4b6204264b9ca718dacdaf1a47f4
            try {
                response = client.send(request, HttpResponse.BodyHandlers.ofString());
                parseJsonResponse(response.body(), centralTable, ticker);
            } catch (Exception e) {
                System.out.println("\n---<Error: " + e.getMessage() + " - It's likely that " + ticker.get(0).toString() + " was not a valid ticker.>---\n");
            }

        } else {
            String symbols = ticker.get(0) + "," + ticker.get(1);
            System.out.println("Here");
            System.out.println(symbols);
            URL = "https://api.twelvedata.com/time_series?&start_date=" + startDate + "&end_date=" + endDate + "&symbol=" + ticker.get(0).toString() + "," + ticker.get(1).toString() + "&interval=1day&apikey=" + APIKey;
            System.out.println(URL);
            request = HttpRequest.newBuilder().uri(URI.create(URL)).build();
            System.out.println("Past URL ");
            try {
                response = client.send(request, HttpResponse.BodyHandlers.ofString());
                parseJsonResponse(response.body(), centralTable, ticker);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    private static void parseJsonResponse(String responseBody, StockHashTable centralTable, LinkedList<String> tickers) {
        JSONObject json = new JSONObject(responseBody);

        // Case 1: Single symbol response
        if (json.has("meta")) {
            parseSymbol(json, centralTable);
        }
        // Case 2: Multiple symbols in the response
        else {
            Set<String> keys = json.keySet();
            for (String key : keys) {
                if (json.getJSONObject(key).has("meta")) {
                    parseSymbol(json.getJSONObject(key), centralTable);
                }
            }
        }
    }

    // Helper method to parse information from JSON for a specific symbol
    private static void parseSymbol(JSONObject json, StockHashTable centralTable) {
        String symbol = json.getJSONObject("meta").getString("symbol");
        JSONArray values = json.getJSONArray("values");

        for (int i = 0; i < values.length(); i++) {
            JSONObject data = values.getJSONObject(i);
            String date = data.getString("datetime");
            double open = data.getDouble("open");
            double high = data.getDouble("high");
            double low = data.getDouble("low");
            double close = data.getDouble("close");
            long volume = data.getLong("volume");

            // Output or process the data
            System.out.printf("Symbol: %s, Date: %s, Open: %.2f, High: %.2f, Low: %.2f, Close: %.2f, Volume: %d%n",
                    symbol, date, open, high, low, close, volume);

            // Insert into centralTable (or other processing as required)
            String key = purify(date, symbol);
            if (centralTable.get(key) == null) {
                String value = String.format("Date: %s\nOpen: %.2f\nHigh: %.2f\nLow: %.2f\nClose: %.2f\nVolume: %d",
                        date, open, high, low, close, volume);
                centralTable.put(key, value);
            }
        }
    }

    // Method to generate a unique key for storing data in centralTable
    public static String purify(String date, String ticker) {
        date = date.replaceAll("-", "");
        int intDate = Integer.parseInt(date);
        int tickerHash = 0;
        for (char ch : ticker.toCharArray()) {
            tickerHash += (int) ch;
        }
        return String.valueOf(intDate + tickerHash);
    }
}
