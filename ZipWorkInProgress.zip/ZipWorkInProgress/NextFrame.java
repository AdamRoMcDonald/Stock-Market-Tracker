import java.util.Hashtable;

public class NextFrame {
    String nextFrame;
    int calcFlag;

    public NextFrame(String nextFrame) {
        this.nextFrame = nextFrame;
    }
    public NextFrame() {
        nextFrame = "";
    }

    public void setNextFrame(String nextFrame, StockHashTable HT, APIAccessor AI) {
        this.nextFrame = nextFrame;
        NumStocks numStocks = new NumStocks();
        String numStocksString = numStocks.getNumStocks();
        switch(nextFrame) {
            case "loadIn":
                calcFlag = 0;
                break;

            case "useInf":
                calcFlag = 1;
                break;

        }
        new LoadInfo(numStocksString, HT, AI, calcFlag);


    }

    public String getNextFrame() {
        return nextFrame;
    }






}
