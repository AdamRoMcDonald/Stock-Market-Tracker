import java.util.Hashtable;

public class Driver {
    public static void main(String[] args) {
        StockHashTable SHT = new StockHashTable();
        NextFrame NF = new NextFrame();
        APIAccessor AI = new APIAccessor();

        MainFrame frame = new MainFrame( SHT, AI);




    }
}
