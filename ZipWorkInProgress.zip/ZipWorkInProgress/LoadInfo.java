import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import java.util.LinkedList;

public class LoadInfo extends JFrame implements ActionListener {
    LinkedList tickerNames;

    @Override
    public void actionPerformed(ActionEvent e) {

    }
    public LoadInfo(String numStocks, StockHashTable HT, APIAccessor AI, int calcFlag) {

        tickerNames = new LinkedList();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Load Info");
        this.setSize(650, 650);
        this.setLayout(null);
        this.setVisible(true);
        this.setResizable(false);



        getTickersPanel GTP = new getTickersPanel();
        this.add(GTP.Return(numStocks));
        System.out.println(GTP.tickerNames.toString());

        getDatePanel GDP = new getDatePanel();
        this.add(GDP.Return(numStocks, GTP.tickerNames, HT, this, AI, calcFlag));













    }





    }

