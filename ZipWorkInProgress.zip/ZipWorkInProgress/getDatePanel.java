import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Hashtable;
import java.util.LinkedList;

public class getDatePanel implements ActionListener {
    String firstDate;
    String secondDate;



    public JPanel Return(String numStocks, LinkedList tickerNames, StockHashTable HT, JFrame frame, APIAccessor AI, int calcFlag) {
        firstDate = "";
        secondDate = "";

        JPanel datePanel = new JPanel();

        datePanel.setLayout(new FlowLayout());
        datePanel.setBounds(0, 325, 500, 75);
        JButton dateButton = new JButton("Enter");
        String[] dateOptions = {"View a range of days", "View a singular day"};
        JComboBox dateBox = new JComboBox(dateOptions);
        datePanel.add(dateBox);
        datePanel.add(dateButton);


        dateButton.addActionListener(e -> {
            switch (dateBox.getSelectedItem().toString()) {
                case "View a range of days":
                    JTextField firstDateField = new JTextField("YYYY-MM-DD");
                    JTextField secondDateField = new JTextField("YYYY-MM-DD");

// Add components to the panel
                    datePanel.removeAll();
                    datePanel.add(firstDateField);
                    datePanel.add(secondDateField);

// Create and add the button
                    JButton enterDates = new JButton("Enter");
                    datePanel.add(enterDates);

// Refresh the panel
                    datePanel.validate();
                    datePanel.repaint();

// Add an ActionListener to the button
                    enterDates.addActionListener(j -> {
                        // Get the updated text when the button is clicked
                        firstDate = firstDateField.getText();
                        secondDate = secondDateField.getText();

                        // Call the appropriate method with the entered dates
                        if(!tickerNames.isEmpty()) {
                          if(calcFlag == 0) {
                              AI.infoLoader(tickerNames, firstDate, secondDate, HT);
                          }
                          if(calcFlag == 1) {
                              System.out.println("Using loaded info");
                          }
                        } else {
                            System.out.println("Please type in ticker(s) and enter.");
                            new LoadInfo(numStocks, HT, AI, calcFlag);
                            frame.dispose();

                        }


                    });
                break;

                case "View a singular day":
                    JTextField firstDateField1 = new JTextField("YYYY-MM-DD");

                    datePanel.removeAll();
                    datePanel.add(firstDateField1);

                    JButton enterDates1 = new JButton("Enter");
                    datePanel.add(enterDates1);

// Refresh the panel
                    datePanel.validate();
                    datePanel.repaint();

                    enterDates1.addActionListener(j -> {
                        // Get the updated text when the button is clicked
                        String firstDate1 = firstDateField1.getText();
                        if(!tickerNames.isEmpty()) {
                            if(calcFlag == 0) {
                                LocalDate date = LocalDate.parse(firstDate1);
                                LocalDate nextDay = date.plusDays(1);

                                String secondDate1 = (nextDay.format(DateTimeFormatter.ISO_DATE));
                                secondDate1 = secondDate1.replaceAll("'", "");
                                System.out.println("first: " + firstDate1 + " second: " + secondDate1);
                                AI.infoLoader(tickerNames, firstDate1, secondDate1, HT);
                            }
                            if(calcFlag == 1) {
//                                if (HT.get(AI.purify(firstDate1, tickerNames.get(0).toString())) != null) {
//                                    System.out.println(HT.get(AI.purify(firstDate1, tickerNames.get(0).toString())));
//                                    System.out.println("Successfully displayed information from " + firstDate1 + " concerning " + tickerNames.get(0) + " stock from the hashtable.");
//                                }
                            }
                        } else {
                            System.out.println("Please type in ticker(s) and enter.");
                            new LoadInfo(numStocks, HT, AI, calcFlag);
                            frame.dispose();
                        }

                    });

            break;
            }
        });

        return datePanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
