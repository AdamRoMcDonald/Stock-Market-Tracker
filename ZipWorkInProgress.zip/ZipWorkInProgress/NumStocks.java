import javax.swing.*;
import java.util.InputMismatchException;

class NumStocks{

    public String numStocks;
    public NumStocks(){

        String numStocks = JOptionPane.showInputDialog("How many stocks would you like to view");


        setNumStocks(numStocks.replace("null",""));


    }
    public void setNumStocks(String numStocks){
        this.numStocks = numStocks;
    }
    public String getNumStocks(){
        return this.numStocks;
    }
}